<?php

namespace Test;

class HomeController
{
    public function index(){
        echo "test again";
    }
}